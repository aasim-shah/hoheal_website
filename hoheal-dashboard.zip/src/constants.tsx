const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;
const mainUrl = process.env.NEXT_PUBLIC_MAIN_URL;

export { baseUrl, mainUrl };