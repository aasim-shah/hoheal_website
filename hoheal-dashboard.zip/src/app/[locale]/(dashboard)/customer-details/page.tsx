export default function CustomerDetailsPage() {
  return (
    <div>CustomerDetailsPage</div>
  );
}