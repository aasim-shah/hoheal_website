export default function SecurityPage() {
  return (
    <div>SecurityPage</div>
  );
}