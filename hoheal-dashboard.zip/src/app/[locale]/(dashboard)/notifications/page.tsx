export default function NotificationsPage() {
    return (
      <div>NotificationsPage</div>
    );
  }