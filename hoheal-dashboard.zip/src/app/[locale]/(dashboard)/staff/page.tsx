export default function StaffPage() {
  return (
    <div>StaffPage</div>
  );
}