export default function RoomsPage() {
  return (
    <div>RoomsPage</div>
  );
}