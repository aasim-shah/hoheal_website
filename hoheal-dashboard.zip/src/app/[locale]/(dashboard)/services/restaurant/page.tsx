export default function RestaurantPage() {
  return (
    <div>RestaurantPage</div>
  );
}