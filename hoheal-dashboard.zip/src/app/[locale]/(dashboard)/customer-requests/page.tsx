export default function CustomerRequestsPage() {
  return (
    <div>CustomerRequestsPage</div>
  );
}