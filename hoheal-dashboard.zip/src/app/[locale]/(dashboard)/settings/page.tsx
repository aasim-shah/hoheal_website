export default function SettingsPage() {
  return (
    <div>SettingsPage</div>
  );
}