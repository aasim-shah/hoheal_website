export default function DashboardPage() {
  return (
    <div>DashboardPage</div>
  );
}