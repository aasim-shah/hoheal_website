export default function ChatsPage() {
  return (
    <div>ChatsPage</div>
  );
}