export default function RoleManagementPage() {
  return (
    <div>RoleManagementPage</div>
  );
}