export default function CheckOutPage() {
  return (
    <div>CheckOutPage</div>
  );
}