export default function AccountPage() {
  return (
    <div>AccountPage</div>
  );
}