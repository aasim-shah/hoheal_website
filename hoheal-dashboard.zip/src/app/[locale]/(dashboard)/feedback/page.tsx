export default function FeedbackPage() {
  return (
    <div>FeedbackPage</div>
  );
}