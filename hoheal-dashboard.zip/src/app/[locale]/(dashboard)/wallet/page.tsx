export default function WalletPage() {
  return (
    <div>WalletPage</div>
  );
}