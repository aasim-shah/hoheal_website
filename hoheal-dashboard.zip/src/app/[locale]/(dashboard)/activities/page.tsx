export default function ActivitiesPage() {
  return (
    <div>ActivitiesPage</div>
  );
}