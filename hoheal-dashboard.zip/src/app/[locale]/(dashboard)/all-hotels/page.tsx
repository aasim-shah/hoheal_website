export default function AllHotelsPage() {
  return (
    <div>AllHotelsPage</div>
  );
}