export default function CheckInPage() {
  return (
    <div>CheckInPage</div>
  );
}