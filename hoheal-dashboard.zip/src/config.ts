export const signatureColors = {
  "signature-dark": "185 82% 27%",
  "signature": "180 55% 37%",
  "signature-light": "171 43% 54%",
};
